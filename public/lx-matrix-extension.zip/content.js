let r=null;const l=new Set;let s;const c="lx-matrix-badge",f='[data-testid="like"], [data-testid="retweet"], [data-testid="reply"]';function h(){const t=document.createElement("style");t.textContent=`
    .${c} {
      display: inline-flex;
      align-items: center;
      flex: 0 0 auto;
      margin-left: 4px;
      padding: 0 5px;
      border-radius: 4px;
      background: #f9b934;
      color: #000;
      font-size: 10px;
      font-weight: 700;
      line-height: 16px;
      vertical-align: middle;
      white-space: nowrap;
    }
  `,document.head.appendChild(t)}function d(t){var n;const e=(n=t.querySelector('a[href*="/status/"] time'))==null?void 0:n.closest("a"),a=((e==null?void 0:e.getAttribute("href"))??location.pathname).match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d+)/);return a?{handle:a[1].toLowerCase(),tweetId:a[2]}:null}function u(){var e;if(!r)return;const t=document.querySelectorAll('article[data-testid="tweet"]');for(const i of t){const a=d(i);if(!a||!r.has(a.handle))continue;const n=i.querySelector('div[data-testid="User-Name"]');if(!n||n.querySelector(`.${c}`))continue;const o=document.createElement("span");o.className=c,o.textContent="LX 矩阵",o.title="LX 流量矩阵成员 — 互动一下，矩阵会回报你",(e=n.firstElementChild)==null||e.appendChild(o)}}function m(){s===void 0&&(s=window.setTimeout(()=>{s=void 0,u()},500))}function p(t){const e=t.target instanceof Element?t.target:null,i=e==null?void 0:e.closest(f);if(!i)return;const a=i.closest('article[data-testid="tweet"]');if(!a)return;const n=d(a);!n||!(r!=null&&r.has(n.handle))||l.has(n.tweetId)||(l.add(n.tweetId),chrome.runtime.sendMessage({type:"lx:reportEngagement",tweetId:n.tweetId}).catch(()=>{}))}async function w(){let t=[];try{const e=await chrome.runtime.sendMessage({type:"lx:getMemberHandles"});t=Array.isArray(e==null?void 0:e.handles)?e.handles:[]}catch{return}t.length!==0&&(r=new Set(t),h(),u(),new MutationObserver(m).observe(document.body,{childList:!0,subtree:!0}),document.addEventListener("click",p,!0))}w();
